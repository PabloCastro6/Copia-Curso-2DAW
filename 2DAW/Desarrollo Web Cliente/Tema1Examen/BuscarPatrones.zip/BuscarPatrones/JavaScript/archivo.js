function comenzar(tipo) {
    const text = document.getElementById("textArea").value.toLowerCase();


    switch(tipo) {
        case 'patrones':
        patrones(text);
        break;

        case 'palabras':
        palabras(text);
        break;

        case 'numPalabras':
            numPlabras(text);
            break;

    }
}


function patrones(text) {
    let text = document.getElementById('textArea').value.toLowerCase();
    const patrones = ["34", "101", "es", "ho"];
    const resultados = {};

    patrones.forEach(patrones => {
        const ocurrencias = text.split(patrones).length - 1;
        if (ocurrencias > 0) {
            resultados[patrones.toUpperCase()] = ocurrencias;
        }
    });

    let mensaje = "Busqueda:";

    for (const patrones in resultados) {
        mensaje += '${patrones}: ${resultados[patrones]} palabra(s)';
    }

    alert(mensaje);
}




function palabras(text) {

    const text = document.getElementById('textArea').value.toLowerCase();

    text.split(" ")

     palabras.sort((a, b) => b.toLowerCase()(a.toLowerCase()));

     const resultado = palabras.join(' ');

     alert('Palabras ordenadas alfabéticamente:' + resultado);


 }


 function numPlabras(text){

    const text = document.getElementById('textArea').value.toLowerCase();


    let palabras = text.split(" ").filter(Boolean);

    let palabrasLargas = palabras.filter(word => word.length >= 7);

    let numeroPalabrasLargas = palabrasLargas.length;

    console.log('Número de palabras con 7 o + caracteres: ' + numeroPalabrasLargas);

 }
